import cv2
import numpy as np
from loguru import logger
from ultralytics import YOLO

from ai_server.yolo_service.redis_client import get_cv_buffer_frames, get_device_state
from ai_server.yolo_service.fan_belt_anomaly import analyze_fan_belt
from ai_server.yolo_service.gauge_anomaly import analyze_gauge
from ai_server.yolo_service.panel_anomaly import analyze_panel
from ai_server.yolo_service.anomaly import save_yolo_result

MODULE_MODEL_PATH = "/app/ai_server/yolo_service/models/module_best.pt"
_module_model = None

MIN_SHARPNESS = 70.0
MIN_CONF = 0.70
MIN_BOX_AREA = 15000

TOTAL_FRAMES = 30
SHARPNESS_FRAMES = 10


def load_module_model():
    global _module_model
    if _module_model is None:
        _module_model = YOLO(MODULE_MODEL_PATH)
        _module_model.fuse()
        logger.info("module_best YOLO 로드 완료")
    return _module_model


def calc_sharpness(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def format_boxes(results, names):
    boxes = []
    for r in results:
        for box in r.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf)
            label = names[int(box.cls)]
            area = (x2 - x1) * (y2 - y1)

            boxes.append({
                "label": label,
                "confidence": conf,
                "xyxy": (x1, y1, x2, y2),
                "area": area
            })
    return boxes


async def run_anomaly_detection():
    logger.info("🚀 run_anomaly_detection() 시작")

    # 1) 장비 타입 확인
    device_info = await get_device_state()
    device_label = device_info.get("label") if device_info else None
    if device_label != "AHU":
        return {
            "detected": False,
            "device_type": device_label,
            "modules": [],
            "anomalies": {},
            "messages": [],
            "message": "AHU가 아님"
        }

    # 2) 프레임 획득 (frame, timestamp 함께 받아야 함)
    frames_ts = await get_cv_buffer_frames(n=TOTAL_FRAMES, with_ts=True)
    if not frames_ts:
        return {"detected": False, "message": "프레임 없음"}

    # frames_ts = [(frame, ts), (frame, ts), ...]
    frames = [f for (f, _) in frames_ts]
    timestamps = [ts for (_, ts) in frames_ts]

    # 가장 최근 프레임의 timestamp
    latest_ts = timestamps[-1]

    # 3) sharpest frame 선택
    sharp_frames = frames[:SHARPNESS_FRAMES]
    sharp_list = [(f, calc_sharpness(f)) for f in sharp_frames]
    sharp_list = [(f, s) for f, s in sharp_list if s > MIN_SHARPNESS]

    if not sharp_list:
        sharpest_frame = frames[-1]
    else:
        sharpest_frame, _ = max(sharp_list, key=lambda x: x[1])

    # 4) YOLO 실행
    module_model = load_module_model()
    yolo_res = module_model.predict(sharpest_frame, conf=MIN_CONF, verbose=False)
    raw_boxes = format_boxes(yolo_res, module_model.names)

    # 5) 후보 박스 필터링
    module_boxes = [
        b for b in raw_boxes
        if b["confidence"] >= MIN_CONF and b["area"] >= MIN_BOX_AREA
    ]

    logger.info(f"📦 module boxes={module_boxes}")

    try:
        if module_boxes:
            top_box = max(module_boxes, key=lambda b: b["confidence"])
            await save_yolo_result(latest_ts, top_box)
            logger.debug("📤 module YOLO overlay 저장 완료")
    except Exception as e:
        logger.exception(f"overlay 저장 오류: {e}")
